# hackapackage
This library was created to publish my own Python hackapackage

## building this package locally
`python setup.py sdict`

## installing this package from GitHub
`pip install git+https://github.com/James-Leslie/example-python-package.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/James-Leslie/example-python-package.git`
